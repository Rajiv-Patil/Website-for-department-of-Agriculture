window.onload =function(){
    for(let i=1; i<=54; i++){
        let card = document.getElementById(i.toString());
        if(i>10){
            card.style.display="none";
        }
        if(i%2===0){
          card.style.backgroundColor = "#d8bfac";
        }
        else{
          card.style.backgroundColor = "#c39b82";
        }
    }
} 

function showmore(){
    for(let i=1; i<54; i++)
    {
        let card = document.getElementById(i.toString());
        card.style.display="flex";
    }
}
